package com.example.week7a

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
